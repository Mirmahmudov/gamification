import React from "react";
import "./ProjectInfo.css";

function ProjectInfo() {
  return <div>ProjectInfo</div>;
}

export default ProjectInfo;
