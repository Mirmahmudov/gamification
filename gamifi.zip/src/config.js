export const baseUrl = "https://codialpointv3.pythonanywhere.com";
