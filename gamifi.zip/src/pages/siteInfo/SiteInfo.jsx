import React from 'react'

function SiteInfo() {
    return (
        <>
            <div className="site_info">
                <div className="imgs">
                    <img src="" alt="" />
                </div>
                
            </div>
        
        </>
    )
}

export default SiteInfo