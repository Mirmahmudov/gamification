export const baseUrl = "https://codialpointv4.pythonanywhere.com";
